/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client/).
 * Copyright (c) 2020 Meteor Development.
 */

package minegame159.meteorclient.modules.player;

import minegame159.meteorclient.modules.Category;
import minegame159.meteorclient.modules.Module;

public class Portals extends Module {
    public Portals() {
        super(Category.Player, "portals", "Allows you to use GUIs normally while in a Nether Portal.");
    }
}
