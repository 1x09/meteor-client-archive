package minegame159.meteorclient.modules.misc;

import minegame159.meteorclient.modules.Category;
import minegame159.meteorclient.modules.ToggleModule;
import minegame159.meteorclient.settings.IntSetting;
import minegame159.meteorclient.settings.Setting;

public class ShulkerTooltip extends ToggleModule {
    private Setting<Integer> lines = addSetting(new IntSetting.Builder()
            .name("lines")
            .description("Number of lines.")
            .defaultValue(8)
            .min(0)
            .build()
    );

    public ShulkerTooltip() {
        super(Category.Misc, "shulker-tooltip", "Better shulker item tooltip.");
    }

    public int lines() {
        return lines.get();
    }
}
